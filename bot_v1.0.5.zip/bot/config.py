# config.py
TELEGRAM_TOKEN = "1899797720:AAHwpuG39Dle57U5bmpVRhbAEoSqF452faE"
CHANNEL_ID = "-1002447094490"
STABILITY_URL = "https://api.cloudflare.com/client/v4/accounts/044689784ef92c3bfe31ce9936718ff8/ai/run/@cf/stabilityai/stable-diffusion-xl-base-1.0"
STABILITY_AUTH_TOKEN = "Bearer 7w9tHRZV9XJGyfoGv5Of_Dpq2gdBd9vlBjfiix6E"
CLOUDFLARE_URL = "https://api.cloudflare.com/client/v4/accounts/044689784ef92c3bfe31ce9936718ff8/ai/run/@cf/black-forest-labs/flux-1-schnell"
HEADERS = {
    'Authorization': 'Bearer 7w9tHRZV9XJGyfoGv5Of_Dpq2gdBd9vlBjfiix6E',
    'Content-Type': 'application/json'
}
IMAGE_DIR = "temp_images"

# سایر تنظیمات ثابت
mass = '''
تصاویر شما با موفقیت درون کانال قرار گرفتن :

https://t.me/MahoAi_image
'''

MODE_NAMES = {"precise": "دقیق", "creative": "خلاقانه"}
