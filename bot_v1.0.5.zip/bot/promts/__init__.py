from .generate import generate_prompts

__all__ = ["generate_prompts"]