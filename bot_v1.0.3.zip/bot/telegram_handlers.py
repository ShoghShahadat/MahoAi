# telegram_handlers.py
import os, asyncio
from telegram import Update, InputMediaPhoto, InputMediaDocument, InlineKeyboardButton, InlineKeyboardMarkup, CallbackQuery
from telegram.ext import CallbackContext
from image_generator import generate_image_without_removal, perform_background_removal
from promts import generate_prompts  # فرض بر این است که توابع پرامپت در promts/generate.py قرار دارد
from config import MODE_NAMES, CHANNEL_ID, mass
# دیکشنری تنظیمات کاربران (می‌توانید آن را هم به یک فایل جداگانه انتقال دهید)
user_settings = {}

async def start(update: Update, context: CallbackContext):
    await update.message.reply_text(
        "سلام! خوبی؟ متن خود را ارسال کنید تا تصاویر مربوطه را بسازم.\n"
        "برای تغییر حالت تصویرسازی از دستور /settings استفاده کن.\n"
        "حالت پیش‌فرض: دقیق")

async def settings(update: Update, context: CallbackContext):
    user_id = update.message.from_user.id
    current_mode = user_settings.get(user_id, "precise")
    keyboard = [
        [InlineKeyboardButton(f"حالت دقیق {'✅' if current_mode == 'precise' else ''}", callback_data="mode_precise")],
        [InlineKeyboardButton(f"حالت خلاقانه {'✅' if current_mode == 'creative' else ''}", callback_data="mode_creative")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(
        f"لطفاً حالت مورد نظر خود را انتخاب کنید:\nحالت فعلی: {MODE_NAMES[current_mode]}",
        reply_markup=reply_markup)

async def settings_callback(update: Update, context: CallbackContext):
    query: CallbackQuery = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    if query.data == "mode_precise":
        user_settings[user_id] = "precise"
        await query.edit_message_text("حالت دقیق انتخاب شد. حالا تصاویر با دقت بالا تولید می‌شوند!")
    elif query.data == "mode_creative":
        user_settings[user_id] = "creative"
        await query.edit_message_text("حالت خلاقانه انتخاب شد. تصاویر با خلاقیت بیشتری ساخته می‌شوند!")
    else:
        await query.edit_message_text("انتخاب نامعتبر.")

async def handle_text(update: Update, context: CallbackContext):
    user_id = update.message.from_user.id
    user_text = update.message.text.strip()
    if not user_text:
        await update.message.reply_text("لطفاً یک متن معتبر ارسال کنید.")
        return
    mode = user_settings.get(user_id, "precise")
    # ایجاد تسک جداگانه برای پردازش درخواست
    asyncio.create_task(process_request(update, context, mode))


async def process_request(update: Update, context: CallbackContext, mode: str):
    user_text = update.message.text
    processing_msg = await update.message.reply_text(
        f"در حال پردازش درخواست شما... 🕒\nمدل انتخاب‌شده: {MODE_NAMES[mode]}"
    )
    try:
        # فرض بر این است که generate_prompts سه مقدار برمی‌گرداند
        prompts_array, prompts_caption, prompts_Advertising = await generate_prompts(user_text, mode)
    except Exception as e:
        await update.message.reply_text(f"خطا در تولید پرامپت: {str(e)}")
        return

    total = len(prompts_array)
    image_paths = []

    # پردازش تصاویر به صورت متوالی (دونه به دونه)
    for i, prompt in enumerate(prompts_array, start=1):
        try:
            result = await process_single_image(prompt, i, total, update)
            image_paths.append(result)
        except Exception as e:
            await update.message.reply_text(f"خطا در پردازش تصویر {i}: {str(e)}")
            return


    photos_user = []
    documents_user = []
    for path, is_removed in image_paths:
        if not os.path.exists(path):
            await update.message.reply_text(f"خطا: فایل {path} وجود ندارد!")
            continue
        if is_removed:
            documents_user.append(InputMediaDocument(open(path, 'rb')))
        else:
            photos_user.append(InputMediaPhoto(open(path, 'rb')))
    if photos_user:
        await update.message.reply_media_group(photos_user)
    if documents_user:
        await update.message.reply_media_group(documents_user)
    await update.message.reply_text(prompts_caption)

    photos_channel = []
    documents_channel = []
    if prompts_Advertising == False:
        for path, is_removed in image_paths:
            if not os.path.exists(path):
                continue
            if is_removed:
                documents_channel.append(InputMediaDocument(open(path, 'rb')))
            else:
                photos_channel.append(InputMediaPhoto(open(path, 'rb')))
        if photos_channel:
            await context.bot.send_media_group(chat_id=CHANNEL_ID, media=photos_channel)
            await context.bot.send_message(chat_id=CHANNEL_ID, text=user_text)
        if documents_channel:
            await context.bot.send_media_group(chat_id=CHANNEL_ID, media=documents_channel)
            await context.bot.send_message(chat_id=CHANNEL_ID, text=user_text)
        try:
            await processing_msg.delete()
        except Exception:
            pass
        # پاکسازی فایل‌های موقت
    for path, _ in image_paths:
        if os.path.exists(path):
            os.remove(path)

async def process_single_image(prompt, index: int, total: int, update: Update):
    from image_generator import generate_image_without_removal
    if prompt.get("remove", False):
        image_path, _ = await generate_image_without_removal(prompt)
        new_path = await perform_background_removal(image_path, total, index, update)
        return new_path, True
    else:
        return await generate_image_without_removal(prompt)


# سایر هندلرها و توابع مرتبط در این فایل قرار بگیرند.
