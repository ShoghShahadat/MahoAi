# image_generator.py
import os, io, hashlib, base64, asyncio
import aiohttp
from PIL import Image
from rembg import remove
from config import STABILITY_URL, STABILITY_AUTH_TOKEN, CLOUDFLARE_URL, HEADERS, IMAGE_DIR

# اطمینان از وجود پوشه تصاویر
if not os.path.exists(IMAGE_DIR):
    os.makedirs(IMAGE_DIR)

async def generate_image_cloudflare(prompt: str) -> str:
    payload = {"steps": 8, "prompt": prompt}
    async with aiohttp.ClientSession() as session:
        async with session.post(CLOUDFLARE_URL, headers=HEADERS, json=payload) as response:
            if response.status != 200:
                raise Exception(f"خطا در فراخوانی: {await response.text()}")
            result = await response.json()
            base64_image = result.get("result", {}).get("image")
            if not base64_image:
                raise Exception("خطا در دریافت تصویر")
            image_bytes = base64.b64decode(base64_image)
            image = Image.open(io.BytesIO(image_bytes))
            random_hash = hashlib.sha256(os.urandom(32)).hexdigest()
            filename = f"{random_hash}.jpg"
            filepath = os.path.join(IMAGE_DIR, filename)
            image.save(filepath)
            if not os.path.exists(filepath):
                raise Exception(f"فایل در مسیر {filepath} ذخیره نشد!")
            return filepath

async def generate_image_without_removal(prompt_json: dict) -> tuple:
    if not isinstance(prompt_json, dict):
        raise ValueError("ورودی باید دیکشنری باشد")

    if prompt_json.get("accurate", False):
        prompt = prompt_json.get("prompt", "")
        image_path = await generate_image_cloudflare(prompt)
    else:
        payload = {
            "guidance": prompt_json.get("guidance", 12),
            "height": prompt_json.get("height", 1024),
            "negative_prompt": prompt_json.get("negative_prompt", ""),
            "num_steps": prompt_json.get("steps", 20),
            "prompt": prompt_json.get("prompt", ""),
            "seed": prompt_json.get("seed", 52),
            "width": prompt_json.get("width", 1024)
        }
        headers = {
            'Authorization': STABILITY_AUTH_TOKEN,
            'Content-Type': 'application/json'
        }
        async with aiohttp.ClientSession() as session:
            async with session.post(STABILITY_URL, headers=headers, json=payload) as response:
                if response.status == 200:
                    image_data = await response.read()
                    random_hash = hashlib.sha256(os.urandom(32)).hexdigest()
                    filename = f"{random_hash}.jpg"
                    image_path = os.path.join(IMAGE_DIR, filename)
                    with open(image_path, "wb") as f:
                        f.write(image_data)
                    if not os.path.exists(image_path):
                        raise Exception(f"فایل اصلی در {image_path} ساخته نشد!")
                else:
                    raise Exception(f"خطا در دریافت تصویر: {response.status}")
    # is_removed flag رو هم از prompt_json استخراج می‌کنیم
    is_removed = prompt_json.get("remove", False)
    return image_path, is_removed

# Semaphore برای حذف بک‌گراند
removal_semaphore = asyncio.Semaphore(1)


async def perform_background_removal(image_path: str, total: int, index: int, update) -> str:
    # نمایش پیام شروع حذف بک‌گراند
    progress_msg = await update.message.reply_text(
        f"حذف بک‌گراند تصویر {index}/{total} شروع شد..."
    )
    loop = asyncio.get_running_loop()

    # با استفاده از semaphore اطمینان حاصل می‌کنیم که این عملیات به صورت متوالی اجرا می‌شود
    async with removal_semaphore:
        # خواندن داده‌های تصویر به صورت باینری
        with open(image_path, 'rb') as file:
            input_data = file.read()

        # اجرای تابع remove به صورت غیرهمزمان در یک executor
        removal_task = loop.run_in_executor(None, remove, input_data)
        seconds = 0

        # به‌روزرسانی پیام پیشرفت تا زمان تکمیل عملیات
        while not removal_task.done():
            seconds += 1
            try:
                await progress_msg.edit_text(
                    f"حذف بک‌گراند تصویر {index}/{total} در حال انجام... {seconds} ثانیه"
                )
            except Exception:
                pass
            await asyncio.sleep(1)

        # دریافت خروجی پس از پایان عملیات حذف
        output_data = await removal_task

    # ذخیره تصویر پردازش‌شده
    processed_path = os.path.join(IMAGE_DIR, f"processed_{os.path.basename(image_path)}")
    with open(processed_path, 'wb') as f:
        f.write(output_data)

    try:
        await progress_msg.delete()
    except Exception:
        pass

    # کمی تاخیر برای اطمینان از اتمام کامل عملیات
    await asyncio.sleep(0.2)
    if os.path.exists(processed_path) and os.path.exists(image_path):
        os.remove(image_path)

    return processed_path

